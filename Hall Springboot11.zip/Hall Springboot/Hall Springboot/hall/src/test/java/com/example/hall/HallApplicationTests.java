package com.example.hall;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HallApplicationTests {

    public static void main(String[] args) {
        SpringApplication.run(HallApplicationTests.class, args);
    }
}

