package com.example.hall.service;


import com.example.hall.model.Hall;
import com.example.hall.repository.HallRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class HallService {

    @Autowired
    private HallRepository hallRepository;

    public List<Hall> getAllHalls() {
        return hallRepository.findAll();
    }

    public Optional<Hall> getHallById(Long id) {
        return hallRepository.findById(id);
    }

    public Hall createHall(Hall hall) {
        return hallRepository.save(hall);
    }

    public Hall updateHall(Long id, Hall hall) {
        if (hallRepository.existsById(id)) {
            hall.setId(id);
            return hallRepository.save(hall);
        }
        return null;
    }

    public void deleteHall(Long id) {
        hallRepository.deleteById(id);
    }
}
