package com.example.hall.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.hall.model.Payment;
import com.example.hall.repository.PaymentRepository;

import java.util.List;
import java.util.Optional;

@Service
public class PaymentService {
    @Autowired
    private PaymentRepository paymentRepository;

    public Payment processPayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    public Optional<Payment> getPaymentById(Long id) {
        return paymentRepository.findById(id);
    }

    public Payment updatePayment(Long id, Payment paymentDetails) {
        return paymentRepository.findById(id)
                .map(payment -> {
                    payment.setPaymentMethod(paymentDetails.getPaymentMethod());
                    payment.setAmount(paymentDetails.getAmount());
                    payment.setStatus(paymentDetails.getStatus());
                    payment.setTransactionId(paymentDetails.getTransactionId());
                    return paymentRepository.save(payment);
                })
                .orElseGet(() -> {
                    paymentDetails.setId(id);
                    return paymentRepository.save(paymentDetails);
                });
    }

    public void deletePayment(Long id) {
        paymentRepository.deleteById(id);
    }
}