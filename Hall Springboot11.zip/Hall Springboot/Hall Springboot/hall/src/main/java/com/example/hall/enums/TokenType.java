package com.example.hall.enums;

public enum TokenType {
    BEARER
}
