package com.example.hall.service;



import com.example.hall.dto.request.LoginRequest;
import com.example.hall.dto.request.RegisterRequest;
import com.example.hall.dto.response.LoginResponse;

public interface AuthService {
    String register(RegisterRequest registerRequest);

    LoginResponse login(LoginRequest loginRequest);

    String createAdmin();
}
