package com.example.hall.service;

import com.example.hall.model.Admin;
import com.example.hall.repository.AdminRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class AdminService {

    @Autowired
    private AdminRepository adminRepository;

    public List<Admin> findAllHalls() {
        return adminRepository.findAll();
    }

    public Optional<Admin> findHallById(Long id) {
        return adminRepository.findById(id);
    }

    public Admin saveHall(Admin hall) {
        return adminRepository.save(hall);
    }

    public void deleteHall(Long id) {
        adminRepository.deleteById(id);
    }

    public Admin updateHall(Long id, Admin hallDetails) {
        Admin admin = adminRepository.findById(id).orElseThrow(() -> new RuntimeException("Hall not found"));
        admin.setHallName(hallDetails.getHallName());
        admin.setHallType(hallDetails.getHallType());
        admin.setAc(hallDetails.isAc());
        admin.setCapacity(hallDetails.getCapacity());
        admin.setPrice(hallDetails.getPrice());
        return adminRepository.save(admin);
    }
}
