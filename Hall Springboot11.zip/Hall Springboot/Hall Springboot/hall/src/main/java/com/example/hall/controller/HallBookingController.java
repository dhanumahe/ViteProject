// HallBookingController.java
package com.example.hall.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.hall.model.HallBooking;
import com.example.hall.service.HallBookingService;

@RestController
@RequestMapping("/api/bookings")
public class HallBookingController {

    @Autowired
    private HallBookingService hallBookingService;

    @GetMapping
    public List<HallBooking> getAllBookings() {
        return hallBookingService.getAllBookings();
    }

    @GetMapping("/{id}")
    public ResponseEntity<HallBooking> getBookingById(@PathVariable Long id) {
        HallBooking booking = hallBookingService.getBookingById(id)
                .orElseThrow(() -> new RuntimeException("Booking not found"));
        return ResponseEntity.ok().body(booking);
    }

    @PostMapping
    public HallBooking createBooking(@RequestBody HallBooking booking) {
        return hallBookingService.createBooking(booking);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HallBooking> updateBooking(@PathVariable Long id, @RequestBody HallBooking bookingDetails) {
        HallBooking updatedBooking = hallBookingService.updateBooking(id, bookingDetails);
        return ResponseEntity.ok(updatedBooking);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteBooking(@PathVariable Long id) {
        hallBookingService.deleteBooking(id);
        return ResponseEntity.noContent().build();
    }
}