package com.example.hall.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import java.util.Set;

import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
public class Hall {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String type;
    private int size;

    @OneToMany(mappedBy = "hall")
    @JsonManagedReference
    private Set<HallBooking> hallBookings;

    public Hall() {
    }

    public Hall(Long id, String name, String type, int size, Set<HallBooking> hallBookings) {
        this.id = id;
        this.name = name;
        this.type = type;
        this.size = size;
        this.hallBookings = hallBookings;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSize() {
        return size;
    }

    public void setSize(int size) {
        this.size = size;
    }

    public Set<HallBooking> getHallBookings() {
        return hallBookings;
    }

    public void setHallBookings(Set<HallBooking> hallBookings) {
        this.hallBookings = hallBookings;
    }
}
