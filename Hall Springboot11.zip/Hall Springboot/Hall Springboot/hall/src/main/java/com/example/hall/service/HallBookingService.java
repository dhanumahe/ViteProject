package com.example.hall.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.hall.model.HallBooking;
import com.example.hall.repository.HallBookingRepository;

@Service
public class HallBookingService {

    @Autowired
    private HallBookingRepository hallBookingRepository;

    public List<HallBooking> getAllBookings() {
        return hallBookingRepository.findAll();
    }

    public Optional<HallBooking> getBookingById(Long id) {
        return hallBookingRepository.findById(id);
    }

    public HallBooking createBooking(HallBooking booking) {
        return hallBookingRepository.save(booking);
    }

    public HallBooking updateBooking(Long id, HallBooking bookingDetails) {
        HallBooking booking = hallBookingRepository.findById(id).orElseThrow(() -> new RuntimeException("Booking not found"));

       // booking.setHall(bookingDetails.getHall()); // Use setHall instead of setHallId
        booking.setHallName(bookingDetails.getHallName());
     //   booking.setBookedBy(bookingDetails.getBookedBy());
        booking.setStartTime(bookingDetails.getStartTime());
        booking.setEndTime(bookingDetails.getEndTime());
        booking.setStatus(bookingDetails.getStatus());

        return hallBookingRepository.save(booking);
    }

    public void deleteBooking(Long id) {
        hallBookingRepository.deleteById(id);
    }
}
