package com.example.hall.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToOne;

@Entity
public class Payment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    private String paymentMethod;
    private Double amount;
    private String status;
    private String transactionId;
    
    @OneToOne
    private HallBooking hallBooking; // Reference to the HallBooking entity

    public Payment() {}

    public Payment(Long id, String paymentMethod, Double amount, String status, String transactionId, HallBooking hallBooking) {
        this.id = id;
        this.paymentMethod = paymentMethod;
        this.amount = amount;
        this.status = status;
        this.transactionId = transactionId;
        this.hallBooking = hallBooking;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }

    public Double getAmount() {
        return amount;
    }

    public void setAmount(Double amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTransactionId() {
        return transactionId;
    }

    public void setTransactionId(String transactionId) {
        this.transactionId = transactionId;
    }

    public HallBooking getHallBooking() {
        return hallBooking;
    }

    public void setHallBooking(HallBooking hallBooking) {
        this.hallBooking = hallBooking;
    }
}
