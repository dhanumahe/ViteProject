// HallBookingRepository.java
package com.example.hall.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.hall.model.HallBooking;

public interface HallBookingRepository extends JpaRepository<HallBooking, Long> {
}